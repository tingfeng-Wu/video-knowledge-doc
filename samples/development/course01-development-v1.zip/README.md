# COURSE01 development sample

source/ contains the video. outputs/ contains the available current M2 result groups.
This sample includes chapter content and document exports.
reference/ contains video metadata and ASR text. No API Key is required to read existing results.
Use tools/unpack_dev_samples.py from the repository to unpack and set the local video path.
The machine result and editorial revision are separate. See sample.json for their IDs.
